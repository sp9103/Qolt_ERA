#include <stdio.h>

#include "Eye_Recovery.h"

int main(){
	Eye_Recovery ERA;

	cv::Mat load_iamge = cv::imread("test_img.jpg");
	cv::Mat load_image2 = cv::imread("test_img.jpg");
	cv::Mat no_image = cv::imread("no_image.jpg");
	cv::imshow("Origin2", no_image);
	cv::imshow("Origin", load_iamge);

	ERA.RefineImage(load_iamge, load_iamge, 0.4);
	ERA.InverseImage(no_image, no_image, 0.0);

	cv::imshow("Inverse Image", no_image);
	cv::imshow("TEST", load_iamge);

	printf("Make Tree...\n");
	ERA.MakeTreeFile(200, 0.4, "DATA.bin", MODE_CORRECTION);
	ERA.OpenDataFile("DATA.bin");
	printf("Make Tree complete!\n");

	ERA.MakeImage_to_Data(load_image2, load_iamge);
	cv::imshow("Real Time Test", load_iamge);
	cv::waitKey(0);

	ERA.DeleteDataBuffer();

	load_image2.release();
	load_iamge.release();

	return 0;
}